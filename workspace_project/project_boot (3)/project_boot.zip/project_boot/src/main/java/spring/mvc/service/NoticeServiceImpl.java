package spring.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.mvc.dao.NoticeDAO;
import spring.mvc.dto.CommentVO;
import spring.mvc.dto.NoticeVO;

@Service
public class NoticeServiceImpl implements NoticeService{
	
	
	@Autowired
	private NoticeDAO noticeDAO;
	
	@Override
	public void AdminWriter(NoticeVO noticeVO) {

		noticeDAO.AdminWriter(noticeVO);
	
	}
	@Override
	public List<NoticeVO> getNoticeList() {

		return noticeDAO.getNoticeList();
	}
	
	
	
	@Override
	public NoticeVO getNoticeView(NoticeVO noticeVO) {
		return noticeDAO.getNoticeView(noticeVO);
	}
	
	@Override
	public void noticeViewUpdate(NoticeVO noticeVO) {
		noticeDAO.noticeViewUpdate(noticeVO);
	}
	
	@Override
	public void noticeDelete(NoticeVO noticeVO) {
		noticeDAO.noticeDelete(noticeVO);
	}
	
	@Override
	public List<CommentVO> getCommentListByNoticeNidx(int nidx) {
		return noticeDAO.getCommentListByNoticeNidx(nidx);
	}
	
	
}
