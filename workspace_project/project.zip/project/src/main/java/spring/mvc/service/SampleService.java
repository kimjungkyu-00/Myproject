package spring.mvc.service;

import java.util.List;

import spring.mvc.dto.CommentVO;
import spring.mvc.dto.NoticeVO;


public interface SampleService {
	
	public void WriteComment(String contents);

	public List<CommentVO> getCommentList();

	public CommentVO getComment(int nidx);

	
}
