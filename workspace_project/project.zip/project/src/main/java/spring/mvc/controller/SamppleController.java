package spring.mvc.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import spring.mvc.dto.CommentVO;
import spring.mvc.dto.NoticeVO;
import spring.mvc.service.NoticeService;
import spring.mvc.service.SampleService;

@Controller
public class SamppleController {
	
	@Autowired
	private SampleService sampleService;
	@Autowired
	private NoticeService noticeService;
	
	
	@RequestMapping(value = "/comment")
	public String main(Model model) {		
		return "tab/comment";
	}
	
	@RequestMapping(value="/writeComment.do")
	public @ResponseBody List<CommentVO> writeComment(@RequestParam("contents") String contents,@RequestParam("nidx") int nidx){
		// (003_1)그리고 Comment Key값으로 다시 아래서 조회?
		//  https://marobiana.tistory.com/23 참조
		System.out.println("writeComment");
		sampleService.WriteComment(contents);
//		CommentVO commentVO =  sampleService.getComment(noticeVO.getNidx());
		
		List<CommentVO> commentList= noticeService.getCommentListByNoticeNidx(nidx);
		
		
		return commentList;

	}
	
}
