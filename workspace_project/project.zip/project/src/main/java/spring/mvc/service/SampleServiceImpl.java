package spring.mvc.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.mvc.dao.SampleDAO;
import spring.mvc.dto.CommentVO;
import spring.mvc.dto.NoticeVO;

@Service
public class SampleServiceImpl implements SampleService{
	
	@Autowired
	private SampleDAO sampleDAO;
	
	@Override
	public void WriteComment(String contents) {
		sampleDAO.insertComment(contents);

	}

	@Override
	public List<CommentVO> getCommentList(){
		return sampleDAO.getCommentList();
	}

	@Override
	public CommentVO getComment(int nidx) {
		return sampleDAO.getComment(nidx);
	}

}
