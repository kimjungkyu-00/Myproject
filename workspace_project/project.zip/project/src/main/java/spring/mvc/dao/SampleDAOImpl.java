package spring.mvc.dao;


import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import spring.mvc.dto.CommentVO;
import spring.mvc.dto.NoticeVO;

@Repository
public class SampleDAOImpl implements SampleDAO{
	@Autowired
	private SqlSession sqlSession;
	private String namespace = "spring.mvc.dto.CommentVO";
	
	@Override
	public void insertComment(String contents){
	    sqlSession.insert( namespace+".insertComment",contents);
	}
	
	@Override
	public List<CommentVO> getCommentList(){
		return sqlSession.selectList(namespace+".CommentList");
	}

	@Override
	public CommentVO getComment(int nidx) {
		sqlSession.insert("namespace"+ ".insertComment2",nidx);
		return null;

	}
	
	
}