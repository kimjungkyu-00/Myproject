package spring.mvc.dto;

public class CommentVO {
	private int idx;
	private String contents;
//	private String boardidx;
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
//	public String getBoardidx() {
//		return boardidx;
//	}
//	public void setBoardidx(String boardidx) {
//		this.boardidx = boardidx;
//	}

	
}
