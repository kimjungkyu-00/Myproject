package spring.mvc.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.json.simple.parser.ParseException;

public interface NaverService {
	public List getData() throws IOException, ParseException;
		 

}
