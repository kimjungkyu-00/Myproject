#include <stdio.h>
void max_min(int,int,int*,int*); //�Լ�����

void main(void)
{	
	int max, min;
	
	max_min(10,8,&max,&min);
	
	printf("max = %d,min = %d\n" , max , min);

}


void max_min(int i,int j, int*large, int*small)
{
	it(i >= j)
	{
		*large = i;
		*small = j;
	}
		else
		{
			*large = j;
			*small = i;
		}
	

}
