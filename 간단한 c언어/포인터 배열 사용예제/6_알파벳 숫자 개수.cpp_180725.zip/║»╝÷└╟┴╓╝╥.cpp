#include <stdio.h>

int main(void)
{
	char *pc;
	int *pi;
	double *pd;
	float * abcd;
	
	pc=(char *)10000;
	pi=(int *)10000;
	pd=(double *)10000;
	abcd= (float *)10000;;
	printf("������ pc= %u, pi = %u, pd =%u pe=%u\n", pc, pi,pd,abcd);
	
	pc++;
	pi++;
	pd++;
	abcd++;
	printf("���� �� pc= %u, pi= %u , pd=%u pe=%u\n",pc,pi,pd,abcd);
	
		
	
	return 0;
}
