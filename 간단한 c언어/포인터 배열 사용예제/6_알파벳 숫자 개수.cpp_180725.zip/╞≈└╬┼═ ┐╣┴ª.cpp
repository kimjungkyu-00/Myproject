#include <stdio.h>
void change(int b[]);

int main(void)
{
	int a[3]= {1,2,3};
	
	printf("%d %d %d\n", a[0],a[1],a[2]);
	change(a);
	printf("%d %d %d\n", a[0],a[1],a[2]);
	return 0;	
}

void change(int b[])
{
	b[0]=4;
	b[1]=5;
	b[2]=6;
}
