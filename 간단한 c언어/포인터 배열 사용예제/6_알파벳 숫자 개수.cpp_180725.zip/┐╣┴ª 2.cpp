#include <stdio.h>

int sum(int a,int b)
{
	int result;
	result = a+b;
	
	return &result;
}

int main(void)
{
	int *p;
	
	p = sum(10,20);
	printf("�� �������� :%d\n",*p);
	retorun 0;
}
