package project1;

public class Banana {

	private int banana;

	public Banana() {}
	
	public Banana(int banana) {
		this.banana=banana;
	}
	public int getBanana() {
		return banana;
	}

	public void setBanana(int banana) {
		this.banana = banana;
	}
	
	
}
