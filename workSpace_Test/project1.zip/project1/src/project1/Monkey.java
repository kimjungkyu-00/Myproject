package project1;

public class Monkey {
	
	private String red;
	private String white;
	private String black;
	private String yellow;
	private String blue;
	private String gray;
	
	
	public Monkey() {}
	
	public Monkey(String red,String white,String black,String yellow,String blue,String gray) {
		this.red=red;
		this.white=white;
		this.black=black;
		this.yellow=yellow;
		this.blue=blue;
		this.gray=gray;
	}
	
	public String getRed() {
		return red;
	}
	public void setRed(String red) {
		this.red = red;
	}
	public String getWhite() {
		return white;
	}
	public void setWhite(String white) {
		this.white = white;
	}
	public String getBlack() {
		return black;
	}
	public void setBlack(String black) {
		this.black = black;
	}
	public String getYellow() {
		return yellow;
	}
	public void setYellow(String yellow) {
		this.yellow = yellow;
	}
	public String getBlue() {
		return blue;
	}
	public void setBlue(String blue) {
		this.blue = blue;
	}
	public String getGray() {
		return gray;
	}
	public void setGray(String gray) {
		this.gray = gray;
	}
	
	
}
